This is a demo live project of springboot
