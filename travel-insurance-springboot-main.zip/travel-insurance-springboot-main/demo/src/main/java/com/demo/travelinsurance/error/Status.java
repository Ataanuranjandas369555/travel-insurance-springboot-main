package com.demo.travelinsurance.error;

import lombok.Data;

@Data
public class Status {
    int statusCode;
    String statusMessage;
}
