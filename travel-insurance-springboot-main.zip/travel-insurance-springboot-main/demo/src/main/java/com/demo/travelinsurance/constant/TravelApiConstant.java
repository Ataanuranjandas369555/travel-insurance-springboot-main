package com.demo.travelinsurance.constant;

public class TravelApiConstant {
    public class StatusCode{
        public static final int BAD_REQUEST=400;
        public static final int INTERNAL_ERROR=500;
    }
}
