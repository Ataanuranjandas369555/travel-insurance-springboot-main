package com.demo.travelinsurance.error;

public class PolicyCreationError {

}
