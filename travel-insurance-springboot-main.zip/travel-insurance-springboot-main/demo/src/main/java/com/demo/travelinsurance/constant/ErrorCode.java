package com.demo.travelinsurance.constant;

public class ErrorCode {
    public static String policyIssuanceFaied="Policy issuance failed";
}
