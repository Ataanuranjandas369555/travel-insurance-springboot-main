package com.demo.travelinsurance.dto;

import lombok.Data;

@Data
public class Document {

    private String type;
    private String id;
    private String expiryDate;
}
